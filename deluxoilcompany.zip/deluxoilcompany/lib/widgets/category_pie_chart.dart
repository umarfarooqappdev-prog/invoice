import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';

class CategoryPieChart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<QuerySnapshot>(
      future: FirebaseFirestore.instance.collection('bookkeeping').get(),
      builder: (context, snapshot) {
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());

        final categoryTotals = <String, double>{};

        for (var doc in snapshot.data!.docs) {
          final data = doc.data() as Map<String, dynamic>;
          final category = data['category'] ?? 'Other';
          final amount = (data['amount'] ?? 0).toDouble();

          categoryTotals[category] = (categoryTotals[category] ?? 0) + amount;
        }

        final total = categoryTotals.values.fold(0.0, (a, b) => a + b);

        final sections = categoryTotals.entries.map((entry) {
          final percent = (entry.value / total) * 100;
          return PieChartSectionData(
            value: entry.value,
            title: '${entry.key}\n${percent.toStringAsFixed(1)}%',
            radius: 50,
            titleStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          );
        }).toList();

        return PieChart(
          PieChartData(
            sections: sections,
            sectionsSpace: 2,
            centerSpaceRadius: 30,
          ),
        );
      },
    );
  }
}
