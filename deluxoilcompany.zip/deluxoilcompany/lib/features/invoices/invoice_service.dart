// lib/services/invoice_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class InvoiceService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Create an invoice & auto-add to bookkeeping
  Future<void> createInvoice({
    required String customerName,
    required String invoiceNumber,
    required List<Map<String, dynamic>> products,
    required double tax,
    required double discount,
    required double total,
  }) async {
    try {
      final now = DateTime.now();

      // 1️⃣ Save invoice to Firestore
      final invoiceRef = await _firestore.collection('invoices').add({
        'customerName': customerName,
        'invoiceNumber': invoiceNumber,
        'products': products,
        'tax': tax,
        'discount': discount,
        'total': total,
        'createdAt': now,
      });

      // 2️⃣ Auto-add transaction to bookkeeping (Income)
      await _firestore.collection('bookkeeping').add({
        'type': 'income',
        'category': 'Sales',
        'amount': total,
        'description': 'Invoice #$invoiceNumber for $customerName',
        'linkedInvoiceId': invoiceRef.id,
        'createdAt': now,
      });

      print('✅ Invoice & bookkeeping entry created successfully.');
    } catch (e) {
      print('❌ Error creating invoice: $e');
      rethrow;
    }
  }

  /// Get all invoices (optional if needed later)
  Future<List<Map<String, dynamic>>> getInvoices() async {
    final snapshot = await _firestore
        .collection('invoices')
        .orderBy('createdAt', descending: true)
        .get();

    return snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
  }
}
