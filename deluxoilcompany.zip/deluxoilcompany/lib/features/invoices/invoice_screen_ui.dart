import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'invoice_service.dart'; // Adjust path if needed

class InVoiceScreen extends StatefulWidget {
  const InVoiceScreen({Key? key}) : super(key: key);

  @override
  State<InVoiceScreen> createState() => _InVoiceScreenState();
}

class _InVoiceScreenState extends State<InVoiceScreen> {
  final _customerController = TextEditingController();
  final _taxController = TextEditingController(text: "0");
  final _discountController = TextEditingController(text: "0");
  List<Map<String, dynamic>> _products = [];

  int invoiceNumber = DateTime.now().millisecondsSinceEpoch;

  double get total {
    double subtotal = _products.fold(
      0,
      (sum, p) => sum + (p['price'] * p['qty']),
    );
    double tax = double.tryParse(_taxController.text) ?? 0;
    double discount = double.tryParse(_discountController.text) ?? 0;
    return subtotal + tax - discount;
  }

  void _addProduct() {
    final nameCtrl = TextEditingController();
    final qtyCtrl = TextEditingController();
    final priceCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Add Product"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: "Product Name"),
            ),
            TextField(
              controller: qtyCtrl,
              decoration: const InputDecoration(labelText: "Quantity"),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: priceCtrl,
              decoration: const InputDecoration(labelText: "Price"),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              final name = nameCtrl.text.trim();
              if (name.isEmpty) return;
              setState(() {
                _products.add({
                  'name': name,
                  'qty': double.tryParse(qtyCtrl.text) ?? 1,
                  'price': double.tryParse(priceCtrl.text) ?? 0,
                });
              });
              Navigator.pop(context);
            },
            child: const Text("Add"),
          ),
        ],
      ),
    );
  }

  Future<void> _saveInvoice() async {
    try {
      if (_customerController.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please enter Customer Name")),
        );
        return;
      }
      if (_products.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please add at least one product")),
        );
        return;
      }

      await InvoiceService().createInvoice(
        customerName: _customerController.text.trim(),
        invoiceNumber: invoiceNumber.toString(),
        products: _products,
        tax: double.tryParse(_taxController.text) ?? 0,
        discount: double.tryParse(_discountController.text) ?? 0,
        total: total,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Invoice saved & synced successfully")),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Failed to save invoice: $e")));
    }
  }

  Future<String> _savePdfFile(List<int> bytes, String filename) async {
    if (kIsWeb) {
      // No file saving on web
      return "Saving not supported on Web";
    }
    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/$filename';
    final file = File(filePath);
    await file.writeAsBytes(bytes);
    return filePath;
  }

  Future<void> _generatePDF({bool printDirect = false}) async {
    try {
      final pdf = pw.Document();
      // Use default Helvetica font (no external font)
      final font = pw.Font.helvetica();

      // Load logo from assets
      final logoData = await rootBundle.load('assets/logo.png');
      final logoBytes = logoData.buffer.asUint8List();

      final dateStr = DateFormat('dd MMM yyyy').format(DateTime.now());

      pdf.addPage(
        pw.MultiPage(
          theme: pw.ThemeData.withFont(base: font),
          build: (context) => [
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Image(pw.MemoryImage(logoBytes), width: 80),
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Text(
                      "DELUX OIL COMPANY",
                      style: pw.TextStyle(
                        fontSize: 18,
                        fontWeight: pw.FontWeight.bold,
                        color: PdfColors.blue800,
                      ),
                    ),
                    pw.Text(
                      "Opposite Dubai Shoes Hashshnagri GT Road, Peshawar, Pakistan",
                    ),
                    pw.Text("+92 300 5861490 | "),
                  ],
                ),
              ],
            ),
            pw.SizedBox(height: 20),
            pw.Text(
              "INVOICE",
              style: pw.TextStyle(
                fontSize: 24,
                fontWeight: pw.FontWeight.bold,
                color: PdfColors.blue900,
              ),
            ),
            pw.SizedBox(height: 10),
            pw.Text("Invoice #: $invoiceNumber"),
            pw.Text("Date: $dateStr"),
            pw.Text("Bill To: ${_customerController.text}"),
            pw.SizedBox(height: 20),
            pw.Table.fromTextArray(
              headers: ["Product", "Qty", "Price", "Total"],
              data: _products
                  .map(
                    (p) => [
                      p['name'],
                      p['qty'].toString(),
                      p['price'].toStringAsFixed(2),
                      (p['qty'] * p['price']).toStringAsFixed(2),
                    ],
                  )
                  .toList(),
              headerStyle: pw.TextStyle(
                fontWeight: pw.FontWeight.bold,
                color: PdfColors.white,
              ),
              headerDecoration: pw.BoxDecoration(color: PdfColors.blue800),
              border: pw.TableBorder.all(color: PdfColors.grey),
              cellAlignment: pw.Alignment.centerLeft,
            ),
            pw.SizedBox(height: 20),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.end,
              children: [
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(
                      "Subtotal: ${_products.fold(0.0, (sum, p) => sum + (p['price'] * p['qty'])).toStringAsFixed(2)}",
                    ),
                    pw.Text("Tax: ${_taxController.text}"),
                    pw.Text("Discount: ${_discountController.text}"),
                    pw.Text(
                      "Total: ${total.toStringAsFixed(2)}",
                      style: pw.TextStyle(
                        fontSize: 16,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      );

      final pdfBytes = await pdf.save();

      final savedPath = await _savePdfFile(
        pdfBytes,
        "invoice_$invoiceNumber.pdf",
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Invoice PDF saved at:\n$savedPath")),
      );

      if (printDirect) {
        await Printing.layoutPdf(onLayout: (format) async => pdfBytes);
      } else {
        await Printing.sharePdf(
          bytes: pdfBytes,
          filename: "invoice_$invoiceNumber.pdf",
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error generating PDF: $e")));
    }
  }

  @override
  void dispose() {
    _customerController.dispose();
    _taxController.dispose();
    _discountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Invoice")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: _customerController,
              decoration: const InputDecoration(labelText: "Customer Name"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _addProduct,
              child: const Text("Add Product"),
            ),
            const SizedBox(height: 10),
            ..._products.map(
              (p) => ListTile(
                title: Text("${p['name']} (x${p['qty']})"),
                trailing: Text(
                  "Rs ${(p['qty'] * p['price']).toStringAsFixed(2)}",
                ),
              ),
            ),
            const Divider(),
            TextField(
              controller: _taxController,
              decoration: const InputDecoration(labelText: "Tax"),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _discountController,
              decoration: const InputDecoration(labelText: "Discount"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            Text(
              "Total: Rs ${total.toStringAsFixed(2)}",
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: _saveInvoice,
                    child: const Text("Save"),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _generatePDF(printDirect: false),
                    child: const Text("Save PDF"),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _generatePDF(printDirect: true),
                    child: const Text("Print"),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
