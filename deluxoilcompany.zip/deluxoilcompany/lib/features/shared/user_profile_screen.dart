import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  File? _image;
  String? _imageUrl;

  @override
  void initState() {
    super.initState();
    loadUserData();
  }

  Future<void> loadUserData() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc('user_profile')
        .get();
    if (snapshot.exists) {
      final data = snapshot.data()!;
      nameController.text = data['name'] ?? '';
      emailController.text = data['email'] ?? '';
      setState(() {
        _imageUrl = data['imageUrl'];
      });
    }
  }

  Future<void> pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      final file = File(picked.path);
      final ref =
          FirebaseStorage.instance.ref().child('user_profile/${picked.name}');
      await ref.putFile(file);
      final url = await ref.getDownloadURL();
      setState(() {
        _image = file;
        _imageUrl = url;
      });
    }
  }

  Future<void> saveProfile() async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc('user_profile')
        .set({
      'name': nameController.text,
      'email': emailController.text,
      'imageUrl': _imageUrl ?? '',
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Profile saved.')));
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  Future<void> backupToFirestore() async {
    final prefs = await SharedPreferences.getInstance();
    final backupData = <String, dynamic>{};
    for (String key in prefs.getKeys()) {
      backupData[key] = prefs.get(key);
    }
    await FirebaseFirestore.instance
        .collection('backups')
        .doc('user_backup')
        .set(backupData);
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Backup complete.')));
  }

  Future<void> restoreFromFirestore() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('backups')
        .doc('user_backup')
        .get();
    final prefs = await SharedPreferences.getInstance();
    if (snapshot.exists) {
      final data = snapshot.data() as Map<String, dynamic>;
      for (String key in data.keys) {
        final value = data[key];
        if (value is bool) {
          await prefs.setBool(key, value);
        } else if (value is String) {
          await prefs.setString(key, value);
        } else if (value is int) {
          await prefs.setInt(key, value);
        } else if (value is double) {
          await prefs.setDouble(key, value);
        }
      }
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Restore complete.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              GestureDetector(
                onTap: pickImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: _image != null
                      ? FileImage(_image!)
                      : (_imageUrl != null
                          ? NetworkImage(_imageUrl!) as ImageProvider
                          : null),
                  child: _image == null && _imageUrl == null
                      ? const Icon(Icons.person, size: 50)
                      : null,
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Name'),
              ),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: saveProfile,
                child: const Text('Save Profile'),
              ),
              const Divider(height: 40),
              const Text('Backup & Restore',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: backupToFirestore,
                child: const Text('Backup Preferences'),
              ),
              ElevatedButton(
                onPressed: restoreFromFirestore,
                child: const Text('Restore Preferences'),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () => Navigator.pushNamed(context, '/dashboard'),
                icon: const Icon(Icons.dashboard),
                label: const Text('Go to Dashboard'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
