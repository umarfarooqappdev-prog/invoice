import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../dashboard/dashboard_screen.dart' hide InvoiceScreen;
import '../invoices/invoice_screen_ui.dart';
import '../reports/help_screen.dart';
import 'login_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool notificationsEnabled = false;
  String currency = 'USD';
  bool isDarkMode = false;
  String language = 'English';

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      notificationsEnabled = prefs.getBool('notifications') ?? false;
      currency = prefs.getString('currency') ?? 'USD';
      isDarkMode = prefs.getBool('darkMode') ?? false;
      language = prefs.getString('language') ?? 'English';
    });
  }

  Future<void> saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications', notificationsEnabled);
    await prefs.setString('currency', currency);
    await prefs.setBool('darkMode', isDarkMode);
    await prefs.setString('language', language);
  }

  Future<void> backupToFirestore() async {
    final prefs = await SharedPreferences.getInstance();
    final allPrefs = prefs.getKeys();
    final backupData = <String, dynamic>{};
    for (String key in allPrefs) {
      final value = prefs.get(key);
      backupData[key] = value;
    }
    await FirebaseFirestore.instance
        .collection('backups')
        .doc('user_backup')
        .set(backupData);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Backup complete.')));
  }

  Future<void> restoreFromFirestore() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('backups')
        .doc('user_backup')
        .get();
    final prefs = await SharedPreferences.getInstance();
    if (snapshot.exists) {
      final data = snapshot.data() as Map<String, dynamic>;
      for (String key in data.keys) {
        final value = data[key];
        if (value is bool) {
          await prefs.setBool(key, value);
        } else if (value is String) {
          await prefs.setString(key, value);
        }
      }
      loadSettings();
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Restore complete.')));
    }
  }

  void logout() async {
    await FirebaseAuth.instance.signOut();
    if (mounted) {
      Navigator.of(
        context,
      ).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            ListTile(
              leading: Icon(Icons.receipt),
              title: Text("Invoices"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InVoiceScreen()),
                );
              },
            ),
            SwitchListTile(
              title: const Text('Enable Notifications'),
              value: notificationsEnabled,
              onChanged: (value) {
                setState(() => notificationsEnabled = value);
                saveSettings();
              },
            ),
            SwitchListTile(
              title: const Text('Dark Mode'),
              value: isDarkMode,
              onChanged: (value) {
                setState(() => isDarkMode = value);
                saveSettings();
              },
            ),
            DropdownButton<String>(
              value: currency,
              onChanged: (value) {
                if (value != null) {
                  setState(() => currency = value);
                  saveSettings();
                }
              },
              items: const [
                DropdownMenuItem(value: 'USD', child: Text('USD')),
                DropdownMenuItem(value: 'PKR', child: Text('PKR')),
                DropdownMenuItem(value: 'EUR', child: Text('EUR')),
              ],
            ),
            DropdownButton<String>(
              value: language,
              onChanged: (value) {
                if (value != null) {
                  setState(() => language = value);
                  saveSettings();
                }
              },
              items: const [
                DropdownMenuItem(value: 'English', child: Text('English')),
                DropdownMenuItem(value: 'Urdu', child: Text('Urdu')),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: backupToFirestore,
              child: const Text('Backup to Firestore'),
            ),
            ElevatedButton(
              onPressed: restoreFromFirestore,
              child: const Text('Restore from Firestore'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: logout, child: const Text('Logout')),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Dashboard'),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.help), label: 'Help'),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const DashboardScreen()),
            );
          } else if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            );
          } else if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HelpScreen()),
            );
          }
        },
      ),
    );
  }
}
