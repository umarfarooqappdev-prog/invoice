import 'package:deluxoilcompany/features/bookkeeping/Bookkeeping_Main.dart';
import 'package:deluxoilcompany/features/settings/settings_screen.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import '../invoices/invoice_screen_ui.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  // 🔹 Dashboard data stream
  Stream<Map<String, dynamic>> getDashboardData() {
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1);

    return FirebaseFirestore.instance
        .collection('bookkeeping')
        .where('date', isGreaterThanOrEqualTo: startOfMonth)
        .snapshots()
        .map((snapshot) {
          double totalIncome = 0;
          double totalExpense = 0;
          double pendingPayments = 0;

          for (var doc in snapshot.docs) {
            final data = doc.data();
            final type = data['type'] ?? '';
            final amount = (data['amount'] ?? 0).toDouble();

            if (type == 'income') totalIncome += amount;
            if (type == 'expense') totalExpense += amount;
            if (type == 'pending') pendingPayments += amount;
          }

          return {
            'income': totalIncome,
            'expense': totalExpense,
            'pending': pendingPayments,
          };
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dashboard")),
      body: StreamBuilder<Map<String, dynamic>>(
        stream: getDashboardData(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!;
          final income = data['income'] ?? 0.0;
          final expense = data['expense'] ?? 0.0;
          final pending = data['pending'] ?? 0.0;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 🔹 Overview
                Text(
                  "Overview - ${DateFormat('MMMM yyyy').format(DateTime.now())}",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 16),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildTile("Income", income, Colors.green),
                    _buildTile("Expenses", expense, Colors.red),
                    _buildTile("Pending", pending, Colors.orange),
                  ],
                ),
                const SizedBox(height: 24),

                // 🔹 Quick Actions
                Text(
                  "Quick Actions",
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),

                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _actionButton(
                      context,
                      Icons.note_add,
                      "New Invoice",
                      const InvoiceScreen(),
                    ),
                    _actionButton(
                      context,
                      Icons.attach_money,
                      "Add Income",
                      const AddIncomeScreen(),
                    ),
                    _actionButton(
                      context,
                      Icons.money_off,
                      "Add Expense",
                      const AddExpenseScreen(),
                    ),
                    _actionButton(
                      context,
                      Icons.payment,
                      "Pending Payments",
                      const PendingPaymentsScreen(),
                    ),
                    _actionButton(
                      context,
                      Icons.book_outlined,
                      "Book Keeping",
                      const Bookkeeping(),
                    ),
                    _actionButton(
                      context,
                      Icons.settings,
                      "Settings",
                      const SettingSScreen(),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildTile(String title, double value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color, width: 1.5),
        ),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(fontWeight: FontWeight.bold, color: color),
            ),
            const SizedBox(height: 8),
            Text(
              "PKR ${value.toStringAsFixed(2)}",
              style: TextStyle(fontSize: 16, color: color),
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionButton(
    BuildContext context,
    IconData icon,
    String label,
    Widget screen,
  ) {
    return ElevatedButton.icon(
      onPressed: () {
        Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
      },
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      ),
      icon: Icon(icon),
      label: Text(label),
    );
  }
}

// ----------------------------------------------------
// 🔹 Embedded Pages (Inside the Same File)
// ----------------------------------------------------

class AddIncomeScreen extends StatefulWidget {
  const AddIncomeScreen({Key? key}) : super(key: key);

  @override
  State<AddIncomeScreen> createState() => _AddIncomeScreenState();
}

class _AddIncomeScreenState extends State<AddIncomeScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descController = TextEditingController();

  Future<void> _saveIncome() async {
    if (_amountController.text.isEmpty) return;

    await FirebaseFirestore.instance.collection('bookkeeping').add({
      'type': 'income',
      'amount': double.parse(_amountController.text),
      'description': _descController.text,
      'date': DateTime.now(),
    });

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Income")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Amount"),
            ),
            TextField(
              controller: _descController,
              decoration: const InputDecoration(labelText: "Description"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _saveIncome, child: const Text("Save")),
          ],
        ),
      ),
    );
  }
}

class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen({Key? key}) : super(key: key);

  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descController = TextEditingController();

  Future<void> _saveExpense() async {
    if (_amountController.text.isEmpty) return;

    await FirebaseFirestore.instance.collection('bookkeeping').add({
      'type': 'expense',
      'amount': double.parse(_amountController.text),
      'description': _descController.text,
      'date': DateTime.now(),
    });

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Expense")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Amount"),
            ),
            TextField(
              controller: _descController,
              decoration: const InputDecoration(labelText: "Description"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _saveExpense, child: const Text("Save")),
          ],
        ),
      ),
    );
  }
}

class PendingPaymentsScreen extends StatelessWidget {
  const PendingPaymentsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pending Payments")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('bookkeeping')
            .where('type', isEqualTo: 'pending')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.data!.docs.isEmpty)
            return const Center(child: Text("No pending payments"));

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;
              return ListTile(
                title: Text(data['description'] ?? ''),
                subtitle: Text("PKR ${data['amount']}"),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

class InvoiceScreen extends StatelessWidget {
  const InvoiceScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InVoiceScreen();
  }
}

class Bookkeeping extends StatelessWidget {
  const Bookkeeping({super.key});

  @override
  Widget build(BuildContext context) {
    return BookkeepingMainPage();
  }
}

class SettingSScreen extends StatelessWidget {
  const SettingSScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SettingsScreen();
  }
}
