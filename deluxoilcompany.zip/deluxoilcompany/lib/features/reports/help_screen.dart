import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Help & About Us')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('About Us',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(
                'This bookkeeping app is designed to simplify your financial records.'),
            SizedBox(height: 20),
            Text('License',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('This app is open-source under the MIT License.'),
          ],
        ),
      ),
    );
  }
}
