import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class HelpAndReportsScreen extends StatelessWidget {
  const HelpAndReportsScreen({super.key});

  Future<void> _exportReportsToPdf(BuildContext context) async {
    final pdf = pw.Document();
    final snapshot = await FirebaseFirestore.instance
        .collection('invoices')
        .get();

    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Header(level: 0, child: pw.Text('Invoice Report')),
          pw.Table.fromTextArray(
            context: context,
            data: <List<String>>[
              <String>['ID', 'Customer', 'Amount', 'Date'],
              ...snapshot.docs.map((doc) {
                final data = doc.data();
                return [
                  doc.id,
                  data['customer'] ?? '',
                  data['amount'].toString(),
                  data['date'] ?? '',
                ];
              }),
            ],
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Help & Reports')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Help',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'Need help using the app? Contact our support or check the documentation for guidance.',
            ),
            const SizedBox(height: 20),
            const Text(
              'Reports',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () => _exportReportsToPdf(context),
              icon: const Icon(Icons.picture_as_pdf),
              label: const Text('Export Invoice Report as PDF'),
            ),
            const SizedBox(height: 30),
            const Text(
              'Other Options',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            ListTile(
              leading: const Icon(Icons.backup),
              title: const Text('Backup & Restore'),
              onTap: () {
                Navigator.pushNamed(context, '/settings');
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () {
                // Implement logout logic
              },
            ),
          ],
        ),
      ),
    );
  }
}
