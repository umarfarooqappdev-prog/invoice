import 'package:cloud_firestore/cloud_firestore.dart';

class BookkeepingService {
  final CollectionReference bookkeepingCollection = FirebaseFirestore.instance
      .collection('bookkeeping');

  final CollectionReference invoiceCollection = FirebaseFirestore.instance
      .collection('invoices');

  /// Add a new bookkeeping entry
  Future<void> addEntry({
    required double amount,
    required String type, // 'income' or 'expense'
    required String category,
    String? note,
    DateTime? date,
  }) async {
    await bookkeepingCollection.add({
      'amount': amount,
      'type': type,
      'category': category,
      'note': note ?? '',
      'date': (date ?? DateTime.now()).toIso8601String(),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Edit an existing bookkeeping entry
  Future<void> editEntry(String docId, Map<String, dynamic> updatedData) async {
    await bookkeepingCollection.doc(docId).update(updatedData);
  }

  /// Delete a bookkeeping entry
  Future<void> deleteEntry(String docId) async {
    await bookkeepingCollection.doc(docId).delete();
  }

  /// Fetch entries for the current month
  Future<QuerySnapshot> fetchCurrentMonthEntries() {
    DateTime now = DateTime.now();
    DateTime startOfMonth = DateTime(now.year, now.month, 1);
    DateTime startOfNextMonth = DateTime(now.year, now.month + 1, 1);

    return bookkeepingCollection
        .where('date', isGreaterThanOrEqualTo: startOfMonth.toIso8601String())
        .where('date', isLessThan: startOfNextMonth.toIso8601String())
        .get();
  }

  /// Fetch all entries
  Future<QuerySnapshot> fetchAllEntries() {
    return bookkeepingCollection.get();
  }

  /// Add invoice and automatically create income entry in bookkeeping
  Future<void> addInvoiceWithIncome({
    required String customerName,
    required double amount,
    required String description,
    DateTime? date,
  }) async {
    final DateTime invoiceDate = date ?? DateTime.now();

    // Create invoice
    DocumentReference invoiceRef = await invoiceCollection.add({
      'customerName': customerName,
      'amount': amount,
      'description': description,
      'date': invoiceDate.toIso8601String(),
      'createdAt': FieldValue.serverTimestamp(),
    });

    // Add related income entry in bookkeeping
    await addEntry(
      amount: amount,
      type: 'income',
      category: 'Invoice Payment',
      note: 'Auto entry for invoice ${invoiceRef.id}',
      date: invoiceDate,
    );
  }
}
