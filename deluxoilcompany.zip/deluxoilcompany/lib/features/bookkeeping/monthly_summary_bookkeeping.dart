// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:fl_chart/fl_chart.dart';
// import 'package:intl/intl.dart';
// import 'package:pdf/widgets.dart' as pw;
// import 'package:printing/printing.dart';

// class MonthlySummaryScreen extends StatelessWidget {
//   const MonthlySummaryScreen({super.key});

//   Future<void> _exportPdf(Map<String, double> monthlyTotals) async {
//     final pdf = pw.Document();

//     pdf.addPage(
//       pw.Page(
//         build: (pw.Context context) {
//           return pw.Column(
//             crossAxisAlignment: pw.CrossAxisAlignment.start,
//             children: [
//               pw.Text(
//                 'Monthly Summary Report',
//                 style: pw.TextStyle(fontSize: 24),
//               ),
//               pw.SizedBox(height: 20),
//               ...monthlyTotals.entries.map(
//                 (entry) => pw.Text(
//                   '${entry.key}: \$${entry.value.toStringAsFixed(2)}',
//                 ),
//               ),
//             ],
//           );
//         },
//       ),
//     );

//     await Printing.layoutPdf(onLayout: (format) async => pdf.save());
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Monthly Summary'),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.picture_as_pdf),
//             onPressed: () async {
//               final snapshot = await FirebaseFirestore.instance
//                   .collection('bookkeeping')
//                   .get();
//               final docs = snapshot.docs;

//               final Map<String, double> monthlyTotals = {};
//               for (var doc in docs) {
//                 final data = doc.data();
//                 final date = (data['date']).toDate();
//                 final amount = data['amount'] ?? 0.0;
//                 final key = DateFormat('yyyy-MM').format(date);
//                 monthlyTotals.update(
//                   key,
//                   (value) => value + amount,
//                   ifAbsent: () => amount,
//                 );
//               }

//               await _exportPdf(monthlyTotals);
//             },
//           ),
//         ],
//       ),
//       body: FutureBuilder<QuerySnapshot>(
//         future: FirebaseFirestore.instance.collection('bookkeeping').get(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           }
//           final docs = snapshot.data!.docs;

//           final Map<String, double> monthlyTotals = {};
//           for (var doc in docs) {
//             final data = doc.data() as Map<String, dynamic>;
//             final date = (data['date']).toDate();
//             final amount = data['amount'] ?? 0.0;
//             final key = DateFormat('yyyy-MM').format(date);

//             monthlyTotals.update(
//               key,
//               (value) => value + amount,
//               ifAbsent: () => amount,
//             );
//           }

//           final sortedKeys = monthlyTotals.keys.toList()..sort();
//           final List<BarChartGroupData> barGroups = [];

//           for (int i = 0; i < sortedKeys.length; i++) {
//             barGroups.add(
//               BarChartGroupData(
//                 x: i,
//                 barRods: [
//                   BarChartRodData(
//                     toY: monthlyTotals[sortedKeys[i]]!,
//                     width: 18,
//                   ),
//                 ],
//               ),
//             );
//           }

//           return Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const Text(
//                   'Monthly Expense Chart',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//                 const SizedBox(height: 20),
//                 Expanded(
//                   child: BarChart(
//                     BarChartData(
//                       titlesData: FlTitlesData(
//                         bottomTitles: AxisTitles(
//                           sideTitles: SideTitles(
//                             showTitles: true,
//                             getTitlesWidget: (value, meta) => Text(
//                               sortedKeys[value.toInt()].split('-').join('/'),
//                             ),
//                           ),
//                         ),
//                       ),
//                       barGroups: barGroups,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
