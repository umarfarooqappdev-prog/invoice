import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class BookkeepingMainPage extends StatefulWidget {
  const BookkeepingMainPage({super.key});

  @override
  State<BookkeepingMainPage> createState() => _BookkeepingMainPageState();
}

class _BookkeepingMainPageState extends State<BookkeepingMainPage> {
  final _searchController = TextEditingController();
  String _searchQuery = '';

  Stream<QuerySnapshot> _transactionStream() {
    return FirebaseFirestore.instance
        .collection('bookkeeping')
        .orderBy('date', descending: true)
        .snapshots();
  }

  void _openTransactionForm({DocumentSnapshot? doc}) {
    showDialog(
      context: context,
      builder: (_) => TransactionForm(existingDoc: doc),
    );
  }

  void _deleteTransaction(String id) {
    FirebaseFirestore.instance.collection('bookkeeping').doc(id).delete();
  }

  Future<void> _showMonthlySummary() async {
    // Calculate first day and last day of current month
    final now = DateTime.now();
    final firstDayOfMonth = DateTime(now.year, now.month, 1);
    final firstDayNextMonth = (now.month < 12)
        ? DateTime(now.year, now.month + 1, 1)
        : DateTime(now.year + 1, 1, 1);

    // Query firestore for bookkeeping entries in this month
    final querySnapshot = await FirebaseFirestore.instance
        .collection('bookkeeping')
        .where(
          'date',
          isGreaterThanOrEqualTo: Timestamp.fromDate(firstDayOfMonth),
        )
        .where('date', isLessThan: Timestamp.fromDate(firstDayNextMonth))
        .get();

    double totalIncome = 0.0;
    double totalExpense = 0.0;

    for (var doc in querySnapshot.docs) {
      final data = doc.data() as Map<String, dynamic>;
      final type = (data['type'] ?? '').toString().toLowerCase();
      final amount = (data['amount'] ?? 0).toDouble();
      if (type == 'income') {
        totalIncome += amount;
      } else if (type == 'expense') {
        totalExpense += amount;
      }
    }

    final balance = totalIncome - totalExpense;

    // Show dialog with the summary
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Monthly Summary Report'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Month: ${DateFormat('MMMM yyyy').format(now)}'),
            const SizedBox(height: 10),
            Text('Total Income: \$${totalIncome.toStringAsFixed(2)}'),
            Text('Total Expense: \$${totalExpense.toStringAsFixed(2)}'),
            const Divider(),
            Text(
              'Balance: \$${balance.toStringAsFixed(2)}',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: balance >= 0 ? Colors.green : Colors.red,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookkeeping'),
        actions: [
          IconButton(
            icon: const Icon(Icons.summarize),
            tooltip: 'Monthly Summary Report',
            onPressed: _showMonthlySummary,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search by category or note',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                border: const OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.trim().toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _transactionStream(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                var docs = snapshot.data!.docs;
                if (_searchQuery.isNotEmpty) {
                  docs = docs.where((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final category = (data['category'] ?? '')
                        .toString()
                        .toLowerCase();
                    final note = (data['note'] ?? '').toString().toLowerCase();
                    return category.contains(_searchQuery) ||
                        note.contains(_searchQuery);
                  }).toList();
                }

                if (docs.isEmpty) {
                  return const Center(child: Text('No transactions found.'));
                }

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final data = doc.data() as Map<String, dynamic>;
                    final type = data['type'] ?? 'expense';
                    final amount = (data['amount'] ?? 0).toDouble();
                    final date = (data['date'] as Timestamp).toDate();

                    return Card(
                      child: ListTile(
                        title: Text('${data['category']} - ${data['note']}'),
                        subtitle: Text(DateFormat('yyyy-MM-dd').format(date)),
                        trailing: Text(
                          '\$${amount.toStringAsFixed(2)}',
                          style: TextStyle(
                            color: type == 'income' ? Colors.green : Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        onTap: () => _openTransactionForm(doc: doc),
                        onLongPress: () => _deleteTransaction(doc.id),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openTransactionForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class TransactionForm extends StatefulWidget {
  final DocumentSnapshot? existingDoc;

  const TransactionForm({super.key, this.existingDoc});

  @override
  State<TransactionForm> createState() => _TransactionFormState();
}

class _TransactionFormState extends State<TransactionForm> {
  final _formKey = GlobalKey<FormState>();
  String _type = 'expense';
  String _category = '';
  String _note = '';
  double _amount = 0.0;
  DateTime _date = DateTime.now();

  @override
  void initState() {
    super.initState();
    if (widget.existingDoc != null) {
      final data = widget.existingDoc!.data() as Map<String, dynamic>;
      _type = data['type'] ?? 'expense';
      _category = data['category'] ?? '';
      _note = data['note'] ?? '';
      _amount = (data['amount'] ?? 0).toDouble();
      _date = (data['date'] as Timestamp).toDate();
    }
  }

  void _saveTransaction() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final transactionData = {
        'type': _type,
        'category': _category,
        'note': _note,
        'amount': _amount,
        'date': _date,
      };

      if (widget.existingDoc == null) {
        await FirebaseFirestore.instance
            .collection('bookkeeping')
            .add(transactionData);
      } else {
        await FirebaseFirestore.instance
            .collection('bookkeeping')
            .doc(widget.existingDoc!.id)
            .update(transactionData);
      }

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        widget.existingDoc == null ? 'Add Transaction' : 'Edit Transaction',
      ),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                value: _type,
                items: const [
                  DropdownMenuItem(value: 'income', child: Text('Income')),
                  DropdownMenuItem(value: 'expense', child: Text('Expense')),
                ],
                onChanged: (value) => setState(() => _type = value!),
                decoration: const InputDecoration(labelText: 'Type'),
              ),
              TextFormField(
                initialValue: _category,
                decoration: const InputDecoration(labelText: 'Category'),
                validator: (value) => value!.isEmpty ? 'Enter category' : null,
                onSaved: (value) => _category = value!,
              ),
              TextFormField(
                initialValue: _note,
                decoration: const InputDecoration(labelText: 'Note'),
                onSaved: (value) => _note = value ?? '',
              ),
              TextFormField(
                initialValue: _amount > 0 ? _amount.toString() : '',
                decoration: const InputDecoration(labelText: 'Amount'),
                keyboardType: TextInputType.number,
                validator: (value) => value!.isEmpty ? 'Enter amount' : null,
                onSaved: (value) => _amount = double.tryParse(value!) ?? 0.0,
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  final pickedDate = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (pickedDate != null) {
                    setState(() => _date = pickedDate);
                  }
                },
                child: Text(
                  'Select Date: ${DateFormat('yyyy-MM-dd').format(_date)}',
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(onPressed: _saveTransaction, child: const Text('Save')),
      ],
    );
  }
}
